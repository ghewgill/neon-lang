#include "dec64.hpp"

dec64_ dec64_::Nan = dec64_::raw(DEC64_NULL);
dec64_ dec64_::False = dec64_::raw(DEC64_FALSE);
dec64_ dec64_::True = dec64_::raw(DEC64_TRUE);
