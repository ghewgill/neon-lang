#ifndef __DEC64_TEST_H__
#define __DEC64_TEST_H__

int dec64_test_all_base(void);
int dec64_test_all_string(void);
int dec64_test_all_math(void);

#endif
