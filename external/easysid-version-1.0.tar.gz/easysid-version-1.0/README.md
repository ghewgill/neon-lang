# easysid

This is an interface library for [reSID](https://en.wikipedia.org/wiki/ReSID) which is callable from any system that can load dynamic libraries.
The easysid library provides a simplified interface to the C++ `SID` class from reSID.
